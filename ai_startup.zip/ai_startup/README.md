# AI Startup - React Dark Template

Dark product landing page for an AI startup.

Run:

```bash
npm install
npm run dev
```

Customize `src/App.jsx` and `src/index.css` to change content and styles.
