import React from "react";
export default function App(){
  return (
    <div className="app">
      <header className="hero center">
        <div className="container">
          <div className="logo">NeuroOps</div>
        </div>
      </header>
      <main className="container">
        <section className="lead center">
          <h1>AI for System Reliability</h1>
          <p>Predict incidents before they happen with lightweight ML models.</p>
          <div className="cta-row"><button className="btn primary">Request Demo</button></div>
        </section>
        <section className="features cards">
          <article className="card"><h3>Anomaly Detection</h3></article>
          <article className="card"><h3>Auto Remediation</h3></article>
          <article className="card"><h3>Root Cause Analysis</h3></article>
        </section>
      </main>
      <footer className="footer container">© 2025 NeuroOps</footer>
    </div>
  );
}